package com.wang.model;

import com.wang.model.entity.Permission;
import javax.persistence.Table;

/**
 *
 * @author dolyw.com
 * @date 2018/8/30 10:48
 */
@Table(name = "permission")
public class PermissionDto extends Permission {

}