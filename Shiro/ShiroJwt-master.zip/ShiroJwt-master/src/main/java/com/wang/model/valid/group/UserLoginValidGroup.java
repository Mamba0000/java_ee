package com.wang.model.valid.group;

/**
 * User登录校验分组
 * @author dolyw.com
 * @date 2018/10/7 10:12
 */
public interface UserLoginValidGroup {
}
