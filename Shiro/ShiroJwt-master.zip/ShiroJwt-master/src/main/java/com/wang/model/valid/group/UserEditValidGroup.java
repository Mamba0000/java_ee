package com.wang.model.valid.group;

/**
 * User编辑校验分组
 * @author dolyw.com
 * @date 2018/10/7 10:13
 */
public interface UserEditValidGroup {
}
