package com.wang.service.impl;

import com.wang.model.UserDto;
import com.wang.service.IUserService;
import org.springframework.stereotype.Service;

/**
 *
 * @author dolyw.com
 * @date 2018/8/9 15:45
 */
@Service
public class UserServiceImpl extends BaseServiceImpl<UserDto> implements IUserService {
}
