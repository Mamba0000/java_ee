package com.yuanben.hjjdatatool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HjjDataToolApplicationTests {

    @Test
    void contextLoads() {
    }

}
