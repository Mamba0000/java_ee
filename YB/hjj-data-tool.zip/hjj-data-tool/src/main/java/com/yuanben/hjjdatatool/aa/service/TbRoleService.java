package com.yuanben.hjjdatatool.aa.service;

import com.yuanben.hjjdatatool.aa.model.TbRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 后台用户角色表 服务类
 * </p>
 *
 * @author 原本
 * @since 2020-11-14
 */
public interface TbRoleService extends IService<TbRole> {

}
