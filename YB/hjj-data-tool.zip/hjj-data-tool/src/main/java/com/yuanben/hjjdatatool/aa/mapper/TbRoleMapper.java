package com.yuanben.hjjdatatool.aa.mapper;

import com.yuanben.hjjdatatool.aa.model.TbRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 后台用户角色表 Mapper 接口
 * </p>
 *
 * @author 原本
 * @since 2020-11-14
 */
public interface TbRoleMapper extends BaseMapper<TbRole> {

}
