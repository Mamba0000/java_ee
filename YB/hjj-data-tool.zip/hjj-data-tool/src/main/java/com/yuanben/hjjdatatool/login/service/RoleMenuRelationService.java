package com.yuanben.hjjdatatool.login.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yuanben.hjjdatatool.login.model.RoleMenuRelation;

/**
 * 角色菜单关系管理Service
 */
public interface RoleMenuRelationService extends IService<RoleMenuRelation> {
}
