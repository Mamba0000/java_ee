package com.yuanben.hjjdatatool.login.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yuanben.hjjdatatool.login.model.UserRoleRelation;

/**
 * 管理员角色关系管理Service
 */
public interface UserRoleRelationService extends IService<UserRoleRelation> {
}
