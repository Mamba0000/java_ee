package com.yuanben.hjjdatatool.login.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yuanben.hjjdatatool.login.model.RolePermissionRelation;

/**
 * 角色权限关系管理Service
 */
public interface RolePermissionRelationService extends IService<RolePermissionRelation> {
}
