package com.yuanben.hjjdatatool.aa.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 后台用户角色表 前端控制器
 * </p>
 *
 * @author 原本
 * @since 2020-11-14
 */
@RestController
@RequestMapping("/aa/tbRole")
public class TbRoleController {

}

