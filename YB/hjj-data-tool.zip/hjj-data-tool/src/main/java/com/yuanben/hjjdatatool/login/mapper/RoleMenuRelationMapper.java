package com.yuanben.hjjdatatool.login.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yuanben.hjjdatatool.login.model.RoleMenuRelation;

/**
 * <p>
 * 角色菜单关系表 Mapper 接口
 * </p>
 *
 */
public interface RoleMenuRelationMapper extends BaseMapper<RoleMenuRelation> {

}
